<?php
        $db = mysql_connect('sql109.epizy.com', 'epiz_28649929', 'fBl4c9ctMc') or die('Failed to connect: ' . mysql_error());
        mysql_select_db('epiz_28649929_Scoreboard') or die('Failed to access database');
?>